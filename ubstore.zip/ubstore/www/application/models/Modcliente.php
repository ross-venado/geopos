<?php defined('BASEPATH') or exit('No direct script access allowed');

class Modcliente extends CI_Model
{
    public function getTable() {
        $query = $this->db->query('SELECT * FROM cliente');
        return $query->result_array();
    }


    public function getcliente($id) {

        $query = $this->db->query('SELECT * FROM cliente Where idcliente=?', ['id'=>$id]);
        return $query->result_array();
    }

   	public function add($data) {

        $this->db->insert('cliente', $data);
        return $this->db->insert_id();
   	}


    public function edit($data,$id){

                $this->db->where('idcliente', $id);
        return $this->db->update('cliente', $data);
    }

    public function delete($id){
        $this->db->where('idcliente', $id);
        return $this->db->delete('cliente');
    }
}
