<?php defined('BASEPATH') or exit('No direct script access allowed');

class Modelo extends CI_Model
{
    public function ejemplo() {
        $query = $this->db->query('select usuario from usuarios');
        return $query->result_array();
    }
}
