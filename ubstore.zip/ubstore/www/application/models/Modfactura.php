<?php defined('BASEPATH') or exit('No direct script access allowed');

class Modfactura extends CI_Model
{
    public function getTable() {
        $query = $this->db->query('SELECT * FROM factura');
        return $query->result_array();
    }


    public function getfactura($id) {

        $query = $this->db->query('SELECT * FROM factura Where idfactura=?', ['id'=>$id]);
        return $query->result_array();
    }

   	public function add($data) {

        $this->db->insert('factura', $data);
        return $this->db->insert_id();
   	}


    public function edit($data,$id){

                $this->db->where('idfactura', $id);
        return $this->db->update('factura', $data);
    }

    public function delete($id){
        $this->db->where('idfactura', $id);
        return $this->db->delete('factura');
    }

}
