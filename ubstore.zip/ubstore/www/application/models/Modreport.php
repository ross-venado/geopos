<?php defined('BASEPATH') or exit('No direct script access allowed');

class Modreport extends CI_Model
{
    public function autentication($user, $pass) {
        $query = $this->db->query('SELECT * FROM usuarios WHERE usuario=? and clave=MD5(?)',[$user, $pass]);
        return $query->result_array();
    }
}
