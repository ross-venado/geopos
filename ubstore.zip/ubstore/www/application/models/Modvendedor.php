<?php defined('BASEPATH') or exit('No direct script access allowed');

class Modvendedor extends CI_Model
{
    public function getTable() {
        $query = $this->db->query('SELECT * FROM vendedor');
        return $query->result_array();
    }


    public function getVendedor($id) {

        $query = $this->db->query('SELECT * FROM vendedor Where idvendedor=?', ['id'=>$id]);
        return $query->result_array();
    }

   	public function add($data) {

        $this->db->insert('vendedor', $data);
        return $this->db->insert_id();
   	}


    public function edit($data,$id){

                $this->db->where('idvendedor', $id);
        return $this->db->update('vendedor', $data);
    }

    public function delete($id){
        $this->db->where('idvendedor', $id);
        return $this->db->delete('vendedor');
    }

}
