<?php defined('BASEPATH') or exit('No direct script access allowed');

class Modproducto extends CI_Model
{
    public function getTable() {
        $query = $this->db->query('SELECT * FROM producto');
        return $query->result_array();
    }


    public function getproducto($id) {

        $query = $this->db->query('SELECT * FROM producto Where idproducto=?', ['id'=>$id]);
        return $query->result_array();
    }

   	public function add($data) {

        $this->db->insert('producto', $data);
        return $this->db->insert_id();
   	}


    public function edit($data,$id){

                $this->db->where('idproducto', $id);
        return $this->db->update('producto', $data);
    }

    public function delete($id){
        $this->db->where('idproducto', $id);
        return $this->db->delete('producto');
    }
}
