<?php
    function dump($data)
    {
        echo '<pre>' . var_export($data, true) . '</pre>';
    }
