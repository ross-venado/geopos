<h1 style="text-align: center">Bienvenidos a UBSTORE</h1>
<div class="row col-md-3">
	
</div>
<div class="row col-md-3">
	<div class="animation" ><div>
</div>
<div class="row col-md-3">
	<div class="animation" ><div>
</div>
<div class="row col-md-3">
	<div class="animation" ><div>
</div>