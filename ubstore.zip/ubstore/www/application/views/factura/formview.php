<form action="<?=base_url('vendedor')?>" method="post" enctype="multipart/form-data" accept-charset="utf-8">
	<div class="row col-md-8">
		
	    <div class="form-group">
	      <label for="nombre">Nombre:</label>
	      <input type="text" name="nombre" value="<?=$data['nombre'];?>" placeholder="Nombre" class="form-control" readonly>
	    </div>
	    <div class="form-group">
	      <label for="apellido">Apellido:</label>
	      <input type="text" name="apellido" value="<?=$data['apellido'];?>" placeholder="Apellido" class="form-control" readonly>
	    </div>
	    <div class="form-group">
	      <label for="telefono">Telefono:</label>
	      <input type="text" name="telefono" value="<?=$data['telefono'];?>" placeholder="Telefono" class="form-control" readonly>
	    </div>
	    <div class="form-group">
	      <label for="direccion">Direccion:</label>
	      <input type="text" name="Direccion" value="<?=$data['direccion'];?>" placeholder="Direccion" class="form-control" readonly>
	    </div>
	    <div class="form-group">
	      <label for="porcentaje">Porcentaje de Comision:</label>
	      <input type="text" name="porcentaje" value="<?=$data['comision'];?>" placeholder="Porcentaje de Comision" class="form-control" readonly>
	    </div>



	    <input type="submit" name="guardar" value="Atras" class="btn btn-default">
	</div>
</form>

