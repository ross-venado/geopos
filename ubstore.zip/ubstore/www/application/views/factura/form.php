<form action="<?=base_url('vendedor/update')?>" method="post" enctype="multipart/form-data" accept-charset="utf-8">
	<div class="row col-md-8">
		
	    <div class="form-group">
	      <label for="nombre">Nombre:</label>
	      <input type="text" name="nombre" value="<?=$data['nombre'];?>" placeholder="Nombre" class="form-control">
	    </div>
	    <div class="form-group">
	      <label for="apellido">Apellido:</label>
	      <input type="text" name="apellido" value="<?=$data['apellido'];?>" placeholder="Apellido" class="form-control">
	    </div>
	    <div class="form-group">
	      <label for="telefono">Telefono:</label>
	      <input type="text" name="telefono" value="<?=$data['telefono'];?>" placeholder="Telefono" class="form-control">
	    </div>
	    <div class="form-group">
	      <label for="direccion">Direccion:</label>
	      <input type="text" name="direccion" value="<?=$data['direccion'];?>" placeholder="Direccion" class="form-control">
	    </div>
	    <div class="form-group">
	      <label for="comision">Porcentaje de Comision:</label>
	      <input type="text" name="comision" value="<?=$data['comision'];?>" placeholder="Porcentaje de Comision" class="form-control">
	    </div>

	      <input type="hidden" name="idvendedor" value="<?=$data['idvendedor'];?>">
	    <input type="submit" name="guardar" value="Guardar" class="btn btn-default">
		<a class="btn btn-danger" style="float:right" href="<?=base_url('vendedor')?>">Cancelar</a>
	</div>
</form>

