<div class="row">
	<br>
	<br>
</div>

<h4>Esta seguro que quiere eliminar el registro</h4>

<?=$tabla;?>
<div class="row">
	<a class="btn btn-danger" style="float:right" href="<?=base_url('vendedor')?>">Cancelar</a>
	<a class="btn btn-primary" style="float:right" href="<?=base_url('vendedor/confirmar/'.$id)?>">Confirmar</a>
</div>