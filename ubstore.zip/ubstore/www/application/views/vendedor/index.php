<div class="row">
	<br>
	<br>
</div>
<div class="row">
	<a class="btn btn-primary" style="float:right" href="<?=base_url('vendedor/add')?>">Agregar nuevo registro</a>
</div>
<h1>Listado de Registro de Vendedores</h1>
<?=$tabla?>

