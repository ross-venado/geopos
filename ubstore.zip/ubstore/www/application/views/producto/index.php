<div class="row">
	<br>
	<br>
</div>
<div class="row">
	<a class="btn btn-primary" style="float:right" href="<?=base_url('producto/add')?>">Agregar nuevo registro</a>
</div>
<h1>Listado de Registro de Productos</h1>
<?=$tabla?>

