<form action="<?=base_url('producto')?>" method="post" enctype="multipart/form-data" accept-charset="utf-8">
	<div class="row col-md-8">
		
	    <div class="form-group">
	      <label for="nombre">Nombre:</label>
	      <input type="text" name="nombre" value="<?=$data['nombre'];?>" placeholder="Nombre" class="form-control" readonly>
	    </div>
	    <div class="form-group">
	      <label for="apellido">Precio</label>
	      <input type="text" name="apellido" value="<?=$data['precio'];?>" placeholder="Apellido" class="form-control" readonly>
	    </div>




	    <input type="submit" name="guardar" value="Atras" class="btn btn-default">
	</div>
</form>

