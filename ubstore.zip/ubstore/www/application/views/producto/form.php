<form action="<?=base_url('producto/update')?>" method="post" enctype="multipart/form-data" accept-charset="utf-8">
	<div class="row col-md-8">
		
	    <div class="form-group">
	      <label for="nombre">Nombre:</label>
	      <input type="text" name="nombre" value="<?=$data['nombre'];?>" placeholder="Nombre" class="form-control">
	    </div>
	    <div class="form-group">
	      <label for="precio">Precio:</label>
	      <input type="text" name="precio" value="<?=$data['precio'];?>" placeholder="Precio" class="form-control">
	    </div>

	      <input type="hidden" name="idproducto" value="<?=$data['idproducto'];?>">
	    <input type="submit" name="guardar" value="Guardar" class="btn btn-default">
		<a class="btn btn-danger" style="float:right" href="<?=base_url('vendedor')?>">Cancelar</a>
	</div>
</form>

