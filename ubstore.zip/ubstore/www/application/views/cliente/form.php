<form action="<?=base_url('cliente/update')?>" method="post" enctype="multipart/form-data" accept-charset="utf-8">
	<div class="row col-md-8">
		
	    <div class="form-group">
	      <label for="nombre">Nombre:</label>
	      <input type="text" name="nombre" value="<?=$data['nombre'];?>" placeholder="Nombre" class="form-control">
	    </div>
	    <div class="form-group">
	      <label for="nit">NIT:</label>
	      <input type="text" name="nit" value="<?=$data['nit'];?>" placeholder="NIT" class="form-control">
	    </div>
	    <div class="form-group">
	      <label for="direccion">Direccion:</label>
	      <input type="text" name="direccion" value="<?=$data['direccion'];?>" placeholder="Direccion" class="form-control">
	    </div>

	      <input type="hidden" name="idcliente" value="<?=$data['idcliente'];?>">
	    <input type="submit" name="guardar" value="Guardar" class="btn btn-default">
		<a class="btn btn-danger" style="float:right" href="<?=base_url('cliente')?>">Cancelar</a>
	</div>
</form>

