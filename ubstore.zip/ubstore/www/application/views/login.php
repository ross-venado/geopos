<div class="col col-md-4 col-md-offset-4">
  <center><h3>INICIAR SESIÓN</h3></center>
  <?=$formulario?>
</div>

<div class="col col-md-4 col-md-offset-4">
	<a href="<?=base_url('vendedor/update')?>" >Registrarme</a>
</div>
<div class="animation"><div>