<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function index()
	{
		$this->load->view('encabezadologin');
		$this->load->view('login', ['formulario' => $this->generaFormulario()]);
	}

	public function process()
	{
		$this->load->model('modlogin');

		$user = $this->input->post('usuario');
		$pass = $this->input->post('clave');

		$datos = $this->modlogin->autentication($user, $pass);

		if (!empty($datos)) {
			redirect('dashboard');
		} else {
			redirect('login');
		}
	}

	private function generaFormulario() {
		$form  = form_open_multipart('login/process', ['method' => 'post']);
		$form .= form_input('usuario', '', ['placeholder' => 'USUARIO', 'class' => 'form-control']);
		$form .= form_password('clave', '', ['placeholder' => 'CLAVE', 'class' => 'form-control']);
		$form .= form_submit('process', 'Iniciar Sesión', ['class' => 'btn btn-default form-control']);
		$form .= form_close();

		return $form;
	}
}
