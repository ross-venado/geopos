<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function index()
	{
		$this->load->view('encabezado');
		$this->load->view('dashboard', ['tabla' => $this->generaTabla(), 'tabla2' => $this->generaTabla2() ]);
		$this->load->view('pie');
	}

	private function generaTabla() {
		$this->load->library('table');

		// APARIENCIA
		$template = array(
		        'table_open'            => '<table class="table table-striped table-bordered">',
		        'thead_open'            => '<thead>',
		        'thead_close'           => '</thead>',

		        'heading_row_start'     => '<tr>',
		        'heading_row_end'       => '</tr>',
		        'heading_cell_start'    => '<th>',
		        'heading_cell_end'      => '</th>',

		        'tbody_open'            => '<tbody>',
		        'tbody_close'           => '</tbody>',

		        'row_start'             => '<tr>',
		        'row_end'               => '</tr>',
		        'cell_start'            => '<td>',
		        'cell_end'              => '</td>',

		        'row_alt_start'         => '<tr>',
		        'row_alt_end'           => '</tr>',
		        'cell_alt_start'        => '<td>',
		        'cell_alt_end'          => '</td>',

		        'table_close'           => '</table>'
		);

		$this->table->set_template($template);


		// CONTENIDO
		$this->table->set_heading('Name', 'Color', 'Size');

		$data = array(
        	array('Name', 'Color', 'Size'),
        	array('Fred', 'Blue', 'Small'),
        	array('Mary', 'Red', 'Large'),
        	array('John', 'Green', 'Medium')
		);

		return $this->table->generate($data);
	}


	private function generaTabla2() {
		$this->load->library('table');

		// APARIENCIA
		$template = array(
		        'table_open'            => '<table class="table table-striped table-bordered">',
		        'thead_open'            => '<thead>',
		        'thead_close'           => '</thead>',

		        'heading_row_start'     => '<tr>',
		        'heading_row_end'       => '</tr>',
		        'heading_cell_start'    => '<th>',
		        'heading_cell_end'      => '</th>',

		        'tbody_open'            => '<tbody>',
		        'tbody_close'           => '</tbody>',

		        'row_start'             => '<tr>',
		        'row_end'               => '</tr>',
		        'cell_start'            => '<td>',
		        'cell_end'              => '</td>',

		        'row_alt_start'         => '<tr>',
		        'row_alt_end'           => '</tr>',
		        'cell_alt_start'        => '<td>',
		        'cell_alt_end'          => '</td>',

		        'table_close'           => '</table>'
		);

		$this->table->set_template($template);


		// CONTENIDO
		$this->table->set_heading('Nombre de Usuario');

		$this->load->model('modelo');
		$data = $this->modelo->ejemplo();

		return $this->table->generate($data);
	}

}
