<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Producto extends CI_Controller {

    public function __construct()
    {
        parent::__construct();


		$this->load->model('modproducto');

    }




	public function index()
	{
		$this->load->view('encabezado');
		$this->load->view('producto/index', ['tabla' => $this->generaTabla()]);
		$this->load->view('pie');
	}


	private function generaTabla() {
		$this->load->library('table');

		// APARIENCIA
		$template = array(
		        'table_open'            => '<table class="table table-striped table-bordered">',
		        'thead_open'            => '<thead>',
		        'thead_close'           => '</thead>',

		        'heading_row_start'     => '<tr>',
		        'heading_row_end'       => '</tr>',
		        'heading_cell_start'    => '<th>',
		        'heading_cell_end'      => '</th>',

		        'tbody_open'            => '<tbody>',
		        'tbody_close'           => '</tbody>',

		        'row_start'             => '<tr>',
		        'row_end'               => '</tr>',
		        'cell_start'            => '<td>',
		        'cell_end'              => '</td>',

		        'row_alt_start'         => '<tr>',
		        'row_alt_end'           => '</tr>',
		        'cell_alt_start'        => '<td>',
		        'cell_alt_end'          => '</td>',

		        'table_close'           => '</table>'
		);

		$this->table->set_template($template);


		// CONTENIDO
		$this->table->set_heading('id','Nombre','Precio', 'Acciones');


		$data = $this->modproducto->gettable();

		foreach ($data as $key => $value) {
			$value['acciones']= '<a class="" href="'.base_url('producto/view/'.$value['idproducto']).'">Ver</a><br>';
			$value['acciones'].= '<a class="" href="'.base_url('producto/edit/'.$value['idproducto']).'">Editar</a><br>';
			$value['acciones'].= '<a class="" href="'.base_url('producto/delete/'.$value['idproducto']).'">Eliminar</a>';
			$data[$key]=$value;
		}
		//var_dump($data);
		//die();

		return $this->table->generate($data);
	}


	private function generaTabla2($id) {
		$this->load->library('table');

		// APARIENCIA
		$template = array(
		        'table_open'            => '<table class="table table-striped table-bordered">',
		        'thead_open'            => '<thead>',
		        'thead_close'           => '</thead>',

		        'heading_row_start'     => '<tr>',
		        'heading_row_end'       => '</tr>',
		        'heading_cell_start'    => '<th>',
		        'heading_cell_end'      => '</th>',

		        'tbody_open'            => '<tbody>',
		        'tbody_close'           => '</tbody>',

		        'row_start'             => '<tr>',
		        'row_end'               => '</tr>',
		        'cell_start'            => '<td>',
		        'cell_end'              => '</td>',

		        'row_alt_start'         => '<tr>',
		        'row_alt_end'           => '</tr>',
		        'cell_alt_start'        => '<td>',
		        'cell_alt_end'          => '</td>',

		        'table_close'           => '</table>'
		);

		$this->table->set_template($template);


		// CONTENIDO
		$this->table->set_heading('id','Nombre','Precio');


		$data = $this->modproducto->getproducto($id);

		return $this->table->generate($data);
	}





public function view($id){

	$data = $this->modproducto->getproducto($id);

	$this->load->view('encabezado');
	$this->load->view('producto/formview',['data'=>$data[0]]);
	$this->load->view('pie');
	
	
}



public function add(){

	$data=[ 'nombre'	=>'',
			'precio'	=>'',
			'idproducto'=> 0];

	$this->load->view('encabezado');
	$this->load->view('producto/form',['data'=>$data]);
	$this->load->view('pie');

}



public function edit($id){

	$data = $this->modproducto->getproducto($id);


	$data=[ 'nombre'	=>$data[0]['nombre'],
			'precio'	=>$data[0]['precio'],
			'idproducto'=> $id];

	$this->load->view('encabezado');
	$this->load->view('producto/form',['data'=>$data]);
	$this->load->view('pie');
}


public function update($id=0){

	$id 		=$this->input->post('idproducto');
	$nombre 	=$this->input->post('nombre');
	$precio 	=$this->input->post('precio');

	$data =['nombre'	=> $nombre,
			'precio'	=> $precio
			];

	if ($id==0) {
		$result = $this->modproducto->add($data);
        if ($result> 0 || empty($result)) 
        {
           //return TRUE;
           redirect('producto');
        } else {
           return false;
        }

	} else {
		
		$result = $this->modproducto->edit($data, $id);
        if ($result) {
             redirect('producto');
        } else {
             return false;
        }
	}
	

}



public function delete($id){

	

	$this->load->view('encabezado');
	$this->load->view('producto/delete', ['id'=>$id, 'tabla' => $this->generaTabla2($id)]);
	$this->load->view('pie');
}


public function confirmar($id){
	$result = $this->modproducto->delete($id);
        if ($result) {
             redirect('producto');
        } else {
             return false;
        }
}

}
