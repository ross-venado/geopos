<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cliente extends CI_Controller {

    public function __construct()
    {
        parent::__construct();


		$this->load->model('modcliente');

    }




	public function index()
	{
		$this->load->view('encabezado');
		$this->load->view('cliente/index', ['tabla' => $this->generaTabla()]);
		$this->load->view('pie');
	}


	private function generaTabla() {
		$this->load->library('table');

		// APARIENCIA
		$template = array(
		        'table_open'            => '<table class="table table-striped table-bordered">',
		        'thead_open'            => '<thead>',
		        'thead_close'           => '</thead>',

		        'heading_row_start'     => '<tr>',
		        'heading_row_end'       => '</tr>',
		        'heading_cell_start'    => '<th>',
		        'heading_cell_end'      => '</th>',

		        'tbody_open'            => '<tbody>',
		        'tbody_close'           => '</tbody>',

		        'row_start'             => '<tr>',
		        'row_end'               => '</tr>',
		        'cell_start'            => '<td>',
		        'cell_end'              => '</td>',

		        'row_alt_start'         => '<tr>',
		        'row_alt_end'           => '</tr>',
		        'cell_alt_start'        => '<td>',
		        'cell_alt_end'          => '</td>',

		        'table_close'           => '</table>'
		);

		$this->table->set_template($template);


		// CONTENIDO
		$this->table->set_heading('id','Nombre','NIT', 'Direccion', 'Acciones');


		$data = $this->modcliente->gettable();

		foreach ($data as $key => $value) {
			$value['acciones']= '<a class="" href="'.base_url('cliente/view/'.$value['idcliente']).'">Ver</a><br>';
			$value['acciones'].= '<a class="" href="'.base_url('cliente/edit/'.$value['idcliente']).'">Editar</a><br>';
			$value['acciones'].= '<a class="" href="'.base_url('cliente/delete/'.$value['idcliente']).'">Eliminar</a>';
			$data[$key]=$value;
		}
		//var_dump($data);
		//die();

		return $this->table->generate($data);
	}


	private function generaTabla2($id) {
		$this->load->library('table');

		// APARIENCIA
		$template = array(
		        'table_open'            => '<table class="table table-striped table-bordered">',
		        'thead_open'            => '<thead>',
		        'thead_close'           => '</thead>',

		        'heading_row_start'     => '<tr>',
		        'heading_row_end'       => '</tr>',
		        'heading_cell_start'    => '<th>',
		        'heading_cell_end'      => '</th>',

		        'tbody_open'            => '<tbody>',
		        'tbody_close'           => '</tbody>',

		        'row_start'             => '<tr>',
		        'row_end'               => '</tr>',
		        'cell_start'            => '<td>',
		        'cell_end'              => '</td>',

		        'row_alt_start'         => '<tr>',
		        'row_alt_end'           => '</tr>',
		        'cell_alt_start'        => '<td>',
		        'cell_alt_end'          => '</td>',

		        'table_close'           => '</table>'
		);

		$this->table->set_template($template);


		// CONTENIDO
		$this->table->set_heading('id','Nombre','NIT', 'Direccion');


		$data = $this->modcliente->getcliente($id);

		return $this->table->generate($data);
	}





public function view($id){

	$data = $this->modcliente->getcliente($id);

	$this->load->view('encabezado');
	$this->load->view('cliente/formview',['data'=>$data[0]]);
	$this->load->view('pie');
	
	
}



public function add(){

	$data=[ 'nombre'	=>'',
			'nit'	=>'',
			'direccion' =>'',
			'idcliente'=> 0];

	$this->load->view('encabezado');
	$this->load->view('cliente/form',['data'=>$data]);
	$this->load->view('pie');

}



public function edit($id){

	$data = $this->modcliente->getcliente($id);


	$data=[ 'nombre'	=>$data[0]['nombre'],
			'nit'	=>$data[0]['nit'],
			'direccion' =>$data[0]['direccion'],
			'idcliente'=> $id];

	$this->load->view('encabezado');
	$this->load->view('cliente/form',['data'=>$data]);
	$this->load->view('pie');
}


public function update($id=0){

	$id 		=$this->input->post('idcliente');
	$nombre 	=$this->input->post('nombre');
	$nit 	=$this->input->post('nit');
	$direccion 	=$this->input->post('direccion');

	$data =['nombre'	=> $nombre,
			'nit'		=> $nit,
			'direccion' => $direccion

			];

	if ($id==0) {


		$result = $this->modcliente->add($data);
        if ($result> 0 || empty($result)) 
        {
           //return TRUE;
           redirect('cliente');
        } else {
           return false;
        }

	} else {
		
		$result = $this->modcliente->edit($data, $id);
        if ($result) {
             redirect('cliente');
        } else {
             return false;
        }
	}
	

}



public function delete($id){

	

	$this->load->view('encabezado');
	$this->load->view('cliente/delete', ['id'=>$id, 'tabla' => $this->generaTabla2($id)]);
	$this->load->view('pie');
}


public function confirmar($id){
	$result = $this->modcliente->delete($id);
        if ($result) {
             redirect('cliente');
        } else {
             return false;
        }
}

}
