<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendedor extends CI_Controller {

    public function __construct()
    {
        parent::__construct();


		$this->load->model('modvendedor');

    }




	public function index()
	{
		$this->load->view('encabezado');
		$this->load->view('vendedor/index', ['tabla' => $this->generaTabla()]);
		$this->load->view('pie');
	}


	private function generaTabla() {
		$this->load->library('table');

		// APARIENCIA
		$template = array(
		        'table_open'            => '<table class="table table-striped table-bordered">',
		        'thead_open'            => '<thead>',
		        'thead_close'           => '</thead>',

		        'heading_row_start'     => '<tr>',
		        'heading_row_end'       => '</tr>',
		        'heading_cell_start'    => '<th>',
		        'heading_cell_end'      => '</th>',

		        'tbody_open'            => '<tbody>',
		        'tbody_close'           => '</tbody>',

		        'row_start'             => '<tr>',
		        'row_end'               => '</tr>',
		        'cell_start'            => '<td>',
		        'cell_end'              => '</td>',

		        'row_alt_start'         => '<tr>',
		        'row_alt_end'           => '</tr>',
		        'cell_alt_start'        => '<td>',
		        'cell_alt_end'          => '</td>',

		        'table_close'           => '</table>'
		);

		$this->table->set_template($template);


		// CONTENIDO
		$this->table->set_heading('id','Nombre','Apellido','Telefono', 'Direccion','Porcentaje de Ganancia', 'Acciones');


		$data = $this->modvendedor->gettable();

		foreach ($data as $key => $value) {
			$value['acciones']= '<a class="" href="'.base_url('vendedor/view/'.$value['idvendedor']).'">Ver</a><br>';
			$value['acciones'].= '<a class="" href="'.base_url('vendedor/edit/'.$value['idvendedor']).'">Editar</a><br>';
			$value['acciones'].= '<a class="" href="'.base_url('vendedor/delete/'.$value['idvendedor']).'">Eliminar</a>';
			$data[$key]=$value;
		}
		//var_dump($data);
		//die();

		return $this->table->generate($data);
	}


	private function generaTabla2($id) {
		$this->load->library('table');

		// APARIENCIA
		$template = array(
		        'table_open'            => '<table class="table table-striped table-bordered">',
		        'thead_open'            => '<thead>',
		        'thead_close'           => '</thead>',

		        'heading_row_start'     => '<tr>',
		        'heading_row_end'       => '</tr>',
		        'heading_cell_start'    => '<th>',
		        'heading_cell_end'      => '</th>',

		        'tbody_open'            => '<tbody>',
		        'tbody_close'           => '</tbody>',

		        'row_start'             => '<tr>',
		        'row_end'               => '</tr>',
		        'cell_start'            => '<td>',
		        'cell_end'              => '</td>',

		        'row_alt_start'         => '<tr>',
		        'row_alt_end'           => '</tr>',
		        'cell_alt_start'        => '<td>',
		        'cell_alt_end'          => '</td>',

		        'table_close'           => '</table>'
		);

		$this->table->set_template($template);


		// CONTENIDO
		$this->table->set_heading('id','Nombre','Apellido','Telefono', 'Direccion','Porcentaje de Ganancia');


		$data = $this->modvendedor->getVendedor($id);

		return $this->table->generate($data);
	}





public function view($id){

	$data = $this->modvendedor->getVendedor($id);

	$this->load->view('encabezado');
	$this->load->view('vendedor/formview',['data'=>$data[0]]);
	$this->load->view('pie');
	
	
}



public function add(){

	$data=[ 'nombre'	=>'',
			'apellido'	=>'',
			'telefono'	=>'',
			'direccion' =>'',
			'comision'  =>'',
			'idvendedor'=> 0];

	$this->load->view('encabezado');
	$this->load->view('vendedor/form',['data'=>$data]);
	$this->load->view('pie');

}



public function edit($id){

	$data = $this->modvendedor->getVendedor($id);


	$data=[ 'nombre'	=>$data[0]['nombre'],
			'apellido'	=>$data[0]['apellido'],
			'telefono'	=>$data[0]['telefono'],
			'direccion' =>$data[0]['direccion'],
			'comision'  =>$data[0]['comision'],
			'idvendedor'=> $id];

	$this->load->view('encabezado');
	$this->load->view('vendedor/form',['data'=>$data]);
	$this->load->view('pie');
}


public function update($id=0){

	$id 		=$this->input->post('idvendedor');
	$nombre 	=$this->input->post('nombre');
	$apellido 	=$this->input->post('apellido');
	$telefono 	=$this->input->post('telefono');
	$direccion 	=$this->input->post('direccion');
	$comision 	=$this->input->post('comision');

	$data =['nombre'	=> $nombre,
			'apellido'	=> $apellido,
			'telefono'	=> $telefono,
			'direccion' => $direccion,
			'comision'	=> $comision
			];

	if ($id==0) {


		$result = $this->modvendedor->add($data);
        if ($result> 0 || empty($result)) 
        {
           //return TRUE;
           redirect('vendedor');
        } else {
           return false;
        }

	} else {
		
		$result = $this->modvendedor->edit($data, $id);
        if ($result) {
             redirect('vendedor');
        } else {
             return false;
        }
	}
	

}



public function delete($id){

	

	$this->load->view('encabezado');
	$this->load->view('vendedor/delete', ['id'=>$id, 'tabla' => $this->generaTabla2($id)]);
	$this->load->view('pie');
}


public function confirmar($id){
	$result = $this->modvendedor->delete($id);
        if ($result) {
             redirect('vendedor');
        } else {
             return false;
        }
}

}
